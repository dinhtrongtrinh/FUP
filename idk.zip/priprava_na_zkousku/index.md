2. Cheap FLights - done 
3. Manhattan Distance - done 
6. Text Justification - done 
7. Photographing Skyscrapers - done
8. Non-deterministic Finite Automata - done 
11. Square Code - done 
14. Spiral Matrix - done 
16. Balanced Binary Tree 
17. Minimum Spanning Tree
18. Pretty Printing Binary Numbers
19. Fermat Primality Test
20. Convex Hull